#define BST_TEST_MAIN
#include "bst/test/test.h"
