#pragma warning( disable : 4251 ) // class A needs to have dll-interface to be used by clients of class B
#pragma warning( disable : 4275 ) // non dll-interface class A used as base for dll-interface class B
