//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NSPTool.rc
//
#define IDS_PROJNAME                    100
#define IDR_WMDMLOGGER                  101
#define IDS_LOG_SEV_INFO                201
#define IDS_LOG_SEV_WARN                202
#define IDS_LOG_SEV_ERROR               203
#define IDS_LOG_DATETIME                204
#define IDS_LOG_SRCNAME                 205
#define IDS_DEF_LOGFILE                 301
#define IDS_DEF_MAXSIZE                 302
#define IDS_DEF_SHRINKTOSIZE            303
#define IDS_DEF_LOGENABLED              304
#define IDS_MUTEX_TIMEOUT               401

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
